# So Now We'll Explore The Turtle Module Very Deeply
# It'll Going to Be Fun

from turtle import Turtle,Screen

kacho_kumma = Turtle()
kacho_kumma.color("red")
def draw_square():
    kacho_kumma.forward(100)
    kacho_kumma.right(90)
    kacho_kumma.forward(100)
    kacho_kumma.right(90)
    kacho_kumma.forward(100)
    kacho_kumma.right(90)
    kacho_kumma.forward(100)
    kacho_kumma.right(90)
draw_square()

for _ in range(4):
    kacho_kumma.forward(100)
    kacho_kumma.right(90)




screen = Screen()
# For Holding The Screen
screen.exitonclick()



import heroes
import villains
hero_names = heroes.gen()
print(hero_names)




