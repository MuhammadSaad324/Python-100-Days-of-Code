import pandas

data = pandas.read_csv("nato_phonetic_alphabet.csv")
phonetic_dict = {row.letter : row.code for (index,row) in data.iterrows()}


is_game_on =True
while is_game_on:
    user_input = input("Tell Me Your Name? ").upper()
    if user_input == "EXIT":
        is_game_on = False
    else:
        final_output = [phonetic_dict [letter] for letter in user_input]
        print(final_output)