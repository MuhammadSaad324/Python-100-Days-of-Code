# So Let's create a class and initialize attributes
class Car:
    def __init__(self,name,price):
        self.name=name
        self.price=price
car_1 = Car("Mercedes","$200000")
car_2= Car ("Bugatti Chiron","$2.5M")
print(f"{car_1.name} has a Price of {car_1.price}.\n")
print(f"{car_2.name} has a Price of {car_2.price}.\n")

# A Method of Creating Attributes
# car_1.name="Mercedes"
# print(car_1.name)

# Instagram Class
class Instagram:
    def __init__(self,user_id,user_name):
        self.id = user_id
        self.name = user_name
        self.followers=0
        self.following=0
    def follow (self,user):
        user.followers +=1
        self.following +=1

user_1= Instagram("001","Zelensky")
print(f"{user_1.name} {user_1.id} {user_1.followers}\n")
user_2= Instagram ("002","Mike Thurston")
print(f"{user_2.name} {user_2.id} {user_2.followers}\n")

user_1.follow(user_2)
print(user_1.followers)
print(user_1.following)
print(user_2.followers)
print(user_2.following)

