# Draw Random Walk With RGB

import turtle as t
from turtle import Screen
import random

timmy = t.Turtle()
timmy.shape("turtle")
timmy.pensize(10)
timmy.speed(6)
t.colormode(255)

def random_colors():
    r = random.randint(1,255)
    g = random.randint(1,255)
    b = random.randint(1,255)
    random_color = (r,g,b)
    return random_color


# colors = ["black","deep sky blue","dark turquoise","medium spring green","yellow","saddle brown","maroon","dark violet"]
direction = [0, 90, 180, 270]




for _ in range(200):
    timmy.color(random_colors())
    timmy.setheading(random.choice(direction))
    timmy.forward(20)


screen = Screen()
screen.exitonclick()




