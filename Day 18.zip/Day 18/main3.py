# Draw Random Walk with Random Colors

from turtle import Turtle,Screen
import random

timmy = Turtle()
timmy.shape("turtle")
timmy.speed(6)

colors = ["black","deep sky blue","dark turquoise","medium spring green","yellow","saddle brown","maroon","dark violet"]

directions = [0, 90, 180, 270]

pen_size = [12,10,5,9,15,3,10,10]

for _ in range(200):
    timmy.color(random.choice(colors))
    timmy.setheading(random.choice(directions))
    timmy.pensize(random.choice(pen_size))
    timmy.forward(20)



screen = Screen()
screen.exitonclick()