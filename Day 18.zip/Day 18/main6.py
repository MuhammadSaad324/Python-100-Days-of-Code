import turtle as t
from turtle import Screen
import random

timmy = t.Turtle()
timmy.shape("turtle")
t.colormode(255)


def random_colors():
    r = random.randint(1,255)
    g = random.randint(1,255)
    b = random.randint(1,255)
    random_color = (r,g,b)
    return random_color

timmy.speed(0)

# def draw_circle():
#     for count in range(100):
#         timmy.color(random_colors())
#         timmy.begin_fill()
#         timmy.pendown()
#         timmy.circle(10)
#         timmy.end_fill()
#         timmy.penup()
#         timmy.forward(30)
#         if count % 6 == 0:
#             timmy.penup()
#             timmy.goto(10,20)
# draw_circle()

def draw_grid_circles(rows, cols, gap=30):
    y_start = rows * gap // 2  # Start from top
    x_start = -cols * gap // 2  # Center horizontally
    timmy.penup()
    timmy.goto(x_start, y_start)
    x = x_start
    y = y_start

    for i in range(rows * cols):
        timmy.color(random_colors())
        timmy.begin_fill()
        timmy.circle(10)
        timmy.end_fill()
        timmy.penup()
        timmy.forward(gap)

        # Move to next line after every `cols` circles
        if (i + 1) % cols == 0:
            y -= gap  # Go down a row
            timmy.goto(x_start, y)

draw_grid_circles(rows=10, cols=10)










screen = Screen()
screen.exitonclick()