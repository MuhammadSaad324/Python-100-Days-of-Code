import pandas as pd

health_data = pd.read_csv("New_York_City_Leading_Causes_of_Death_20250604.csv")

# 1 For Showing How Many Males and Females Are in the Data

Males = len (health_data[health_data["Sex"] == "M"])
Females = len (health_data[health_data["Sex"] == "F"])
print(Males)
print(Females)

# 2 Show How Many Males and Females have Diabetes
diabetes_by_sex = health_data[health_data["Leading Cause"] == "Diabetes Mellitus (E10-E14)"]["Sex"].value_counts()
male_diabetes = diabetes_by_sex.get("M",0)
Female_diabetes = diabetes_by_sex.get("F",0)
data_dict = {
    "Gender":["Male","Female"],
    "Diabetes Patients" : [male_diabetes,Female_diabetes]
}
final_data  = pd.DataFrame(data_dict)
print(final_data)

# Show How Many Males and Females Commit Suicide
suicide_by_sex = health_data[health_data["Leading Cause"] == "Intentional Self-Harm (Suicide: X60-X84, Y87.0)"]["Sex"].value_counts()
male_suicide = suicide_by_sex.get("M",0)
Female_suicide = suicide_by_sex.get("F",0)

data2_dict = {
    "Gender" : ["Male","Female"],
    "Suicide Rate" : [male_suicide,Female_suicide]
}
suicide_data = pd.DataFrame(data2_dict)
print(suicide_data)