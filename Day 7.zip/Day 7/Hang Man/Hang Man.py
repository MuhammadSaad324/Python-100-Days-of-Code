import random
from hangman_words import Words_List
from hangman_art import logo, stages
stages = [r'''
  +---+
  |   |
  O   |
 /|\  |
 / \  |
      |
=========
''', r'''
  +---+
  |   |
  O   |
 /|\  |
 /    |
      |
=========
''', r'''
  +---+
  |   |
  O   |
 /|\  |
      |
      |
=========
''', '''
  +---+
  |   |
  O   |
 /|   |
      |
      |
=========''', '''
  +---+
  |   |
  O   |
  |   |
      |
      |
=========
''', '''
  +---+
  |   |
  O   |
      |
      |
      |
=========
''', '''
  +---+
  |   |
      |
      |
      |
      |
=========
''']

Lives=5
print(logo)

Chosen_Words=random.choice(Words_List)
print(Chosen_Words)


placeholder=""
for letter in range(len(Chosen_Words)):
    placeholder+="-"

print(placeholder)
    
Game_Over=False
Guessed_Words=[]
while not Game_Over: 
    Guess=input("Enter the Guessed Letter? ").lower()
    if Guess in Guessed_Words:
        print(f"You've already guessed {Guess}")
    display=""

    for letters in Chosen_Words:
        if letters==Guess:
            display+=letters
            Guessed_Words.append(Guess)
        elif letters in Guessed_Words:
            display+=letters
        else:
            display+="-"
    print(display)

    if Guess not in display:
        Lives-=1
        print(f"Remaining Lives {Lives}")
        if Lives==0:
            Game_Over=True
            print(f"***********************IT WAS '{Chosen_Words}'! YOU LOSE**********************")

    if "-" not in display:
        Game_Over=True
        print("You Win.")

print(stages[Lives])
