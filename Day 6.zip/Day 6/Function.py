# So In Day 6 We are Going To Learn About Function , Indentation , And While Loops
# So What are Functions?
# Functions are Block Of Codes that Executed When it's Called.
# We Write Some Code inside the Function And Call it Whereever We Wanna Use it.

# Let's Look At this Example
def greet(name):
    print("Hello",name)
greet("Osman")

# You Can Call A Function Inside a Function
# You can Apply a For loop on a Function using Range function
