# Tip Calculator
print("Welcome To My Tip Calculator")
Total_Bill=float(input("Please Tell me The Total Bill? $"))
Tip=int(input("How Much Tip You Want to Give? 10,12,15?"))
Total_Persons=int(input("How Many People Will Split The Bill?"))
Bill_Tip=Total_Bill+(Total_Bill*Tip/100)
Final_Amount=Bill_Tip/Total_Persons
print(f"Each Person Should Pay: $ {Final_Amount:.2f}")
