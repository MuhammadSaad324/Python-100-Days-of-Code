# Create Question Class and Make Question and Answer Attribute
class Question:
    def __init__(self,question,correct_answer):
        self.question = question
        self.correct_answer = correct_answer
