programming_dictionary = {
    "Bug": "An error in a program that prevents the program from running as expected.",
    "Function": "A piece of code that you can easily call over and over again."
}

# So Today We are learning About Dictionaries in Python
fruits={"Apple":"Red","PineApple":"Yellow","WaterMelon":"Emerald","Peach":"Pink"}

# For Updating the Existing Value of a Dictionary Element
fruits["Apple"]="Green"

# For Removing An Item From Dictionary
fruits["Banana"]="Yellow"

# Use Loop n it
for x in fruits:
    print(x)
    print(fruits[x])

student_scores = {
    'Harry': 88,
    'Ron': 78,
    'Hermione': 95,
    'Draco': 75,
    'Neville': 60
}

student_grades ={
'Harry': "Exceeds Expectations",
'Ron': "Acceptable",
'Hermione': "Outstanding" ,
'Draco': "Acceptable",
'Neville':"Fail"
}