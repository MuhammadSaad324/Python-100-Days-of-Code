# let's learn about Inheritance in OOP

class Animal:
    def __init__(self):
        self.eyes = 2
        self.attitude = "Aggressive"
    def breathing (self):
        print("Inhale Exhale")

class Lion(Animal):
    def __init__(self):
        super().__init__()
    def breathing(self):
        super().breathing()
        print("Lion is Breathing")

animal_1 = Lion()
print(animal_1.attitude)
animal_1.breathing()
print(animal_1.eyes)