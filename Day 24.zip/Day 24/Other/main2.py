PLACE_HOLDER = "[name]"

# First Extract Names and Make their List
with open(r"/Day 24/Mail Merge Project Start/Input/Names/invited_names.txt") as names_file:
    all_names = names_file.readlines()

# Swap name placeholder with actual names
with open(r"/Day 24/Mail Merge Project Start/Input/Letters/starting_letter.txt") as letter_template:
    letter = letter_template.read()
    for name in all_names:
        striped_names = name.strip()
        final_letter = letter.replace(PLACE_HOLDER,name)
        with open(fr"D:\100 Days Of Code\Day 24\Mail Merge Project Start\Output\All Letters File\letter_for_{name}.txt","w") as save_file:
            save_file.write(final_letter)