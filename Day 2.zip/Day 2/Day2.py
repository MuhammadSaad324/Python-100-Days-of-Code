# In Day 2 We Learn About These Things
# Primitive Data types
print("Hello World!") # String

print(1234) #Integers

print(34.678) #Floats

print(True)   # Booleans
print(False)  # Boolean

# TyCasting Changing The Data Type of a Data
print(int("1234"))

# Type Function
# Round Function

# Mathematical Operation
# Assignment Operator

# And at Last Tip Generator
print("Welcome To My Tip Generator")
Total_Bill=float(input("Enter The Total Amount Of Bill? $"))
Tip=int(input("Enter The Amount Of Tip You Want to Give? 10,12,15?"))
People=int(input("How Many People Will Gonna Split The Bill?"))
Total_Bill_Tip=Total_Bill+(Total_Bill*Tip/100)
Final_Amount=Total_Bill_Tip/People
print(f"Every Person Should Pay : ${Final_Amount:.2f}")