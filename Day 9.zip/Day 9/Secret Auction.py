# TODO-1: Ask the user for input
# TODO-2: Save data into dictionary {name: Bid}
# TODO-3: Whether if new bids need to be added
# TODO-4: Compare bids in dictionary




logo = r'''
                         ___________
                         \         /
                          )_______(
                          |"""""""|_.-._,.---------.,_.-._
                          |       | | |               | | ''-.
                          |       |_| |_             _| |_..-'
                          |_______| '-' `'---------'` '-'
                          )"""""""(
                         /_________\\
                       .-------------.
                      /_______________\\
'''
print(logo)

print("Welcome to Blind Auction! ")

def auction():
    contestant_data = {}
    def entry():
        name=input("What is Your Name? \n").capitalize()
        bid=int(input("What is Your Bid? : $"))
        contestant_data[name]=bid
        print(contestant_data)
    entry()
    while True:
        other_bidders=input("Are there any other bidders? Type 'yes' or 'No'? \n").lower()
        if other_bidders=='yes':
            print("\n" * 50)
            entry()
        else:
            highest_bid=max(contestant_data, key=contestant_data.get)
            print(f"The Winner is {highest_bid} with a bid of ${contestant_data[highest_bid]}.")
            break
auction()