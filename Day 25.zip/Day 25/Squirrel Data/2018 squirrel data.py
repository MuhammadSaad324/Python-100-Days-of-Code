import pandas
color_data = pandas.read_csv("2018_Central_Park_Squirrel_Census_-_Squirrel_Data.csv")
gray_squirrels = len(color_data[color_data["Primary Fur Color"] == "Gray"])
cinnamon_squirrels = len(color_data[color_data["Primary Fur Color"] == "Cinnamon"])
black_squirrels = len(color_data[color_data["Primary Fur Color"] == "Black"])

all_color_data = {
    "Fur_Colors" : ["Gray","Cinnamon","Black"],
    "Quantity": [gray_squirrels,cinnamon_squirrels,black_squirrels]
}
dict_data = pandas.DataFrame(all_color_data)
dict_data.to_csv("fur_colors.csv")