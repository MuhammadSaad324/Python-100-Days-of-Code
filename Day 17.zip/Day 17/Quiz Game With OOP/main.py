from question_model import Question
from data import  question_data
from quiz_brain import QuizBrain
# Make Objects from Question class and Store them in a List

question_bank = []
for item in question_data:
    question = item["question"]
    answer = item["correct_answer"]
    q_1 = Question(question,answer)
    question_bank.append(q_1)

quiz = QuizBrain(question_bank)


while quiz.still_question():
    quiz.show_question()
