# Using LogicaL Operators
print("Welcome To Roller Coaster Ride")
Height=int(input("Please Enter Your Height In Cm ? "))
Finall_Bill=0

if Height>=120:
    print("Yes You Can Ride.")
    Age=int(input("Enter Your Age? "))
    if Age<=12:
        Finall_Bill=5
        print("Kids Ticket Price is $5.")
    elif Age<=18:
        Finall_Bill=5
        print("Teens Ticket Price is $7.")
    elif Age>=45 and Age<=55:
        Finall_Bill=0
        print("Your Ticket is Free.")
    else:
        Finall_Bill=12
        print("Adult's Ticket Price is $12.")
else:
    print("No You Can't Ride.")
