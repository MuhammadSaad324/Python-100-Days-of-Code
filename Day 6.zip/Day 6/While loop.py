# So We'll gonna talk About on While Loops
# While Loops Continues to Run Until a Certain Condition is true. it Stop running when Condition Becomes False.

Fruits=[1,2,3,4,5,6]
i=5
while i>0:
    Fruits.append("Saad")
    i-=1
    print(i)
print(Fruits)

# The Syntax of While Loop is Very Simple
# While # Condition is true:
    # Do This COntinously Until The Condition Becomes False

x=0
while x<10:
    x+=1
    print(x)

x2=0
while x2<20:
    x2+=2
    print(x2)

x3=11
while x3>1:
    x3-=1
    print(x3)
