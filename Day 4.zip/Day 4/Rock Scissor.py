import random

rock = '''
    _______
---'   ____)
      (_____)
      (_____)
      (____)
---.__(___)
'''

paper = '''
    _______
---'   ____)____
          ______)
          _______)
         _______)
---.__________)
'''

scissors = '''
    _______
---'   ____)____
          ______)
       __________)
      (____)
---.__(___)
'''
User_input=int(input("What Do You Choose? Type 0 for Rock, 1 for Paper or 2 for Scissors. "))
if User_input==0:
    print(rock)
elif User_input==1:
    print(paper)
elif User_input==2:
    print(scissors)
All_Choices=[rock,paper,scissors]
Game_Choices=random.randint(0,2)
print(All_Choices[Game_Choices])

# Results
if User_input==Game_Choices:
    print("It's Draw")
elif User_input==0 and Game_Choices==2:
    print("You Win")
elif User_input==1 and Game_Choices==0:
    print("You Win")
elif User_input ==2 and Game_Choices==1:
    print("You Win")
else:
    print("You Lose.")