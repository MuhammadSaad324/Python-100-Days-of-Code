# Let me explain the Classes Objects attributes and Methods in OOP.
from turtle import Turtle,Screen
my_turtle = Turtle()
my_screen = Screen()
# Now the turtle module have so many attributes and methods
# For Understanding Attributes means the things what he has and Method means what he does.

# Use Screen Object Attributes
print(my_screen.canvheight)
print(my_screen.canvwidth)



# Use Turtle Methods
my_turtle.color()
my_turtle.shape("turtle")
my_screen.exitonclick()

# Let me Build A Car class and Clarify all the of your doubts
class Car:                  # This is a Class template
    def __init__(self,name,price,fuel_efficiency):
        self.name=name                              # These are The Attributes
        self.price=price                            # These are The Attributes
        self.fuel_efficiency=fuel_efficiency
    def car_info(self):
        print(f"{self.name} Price {self.price} Fuel Efficiency {self.fuel_efficiency}")
car_1=Car("Mercedes G Wagon","$200000","6")
car_1.car_info()
