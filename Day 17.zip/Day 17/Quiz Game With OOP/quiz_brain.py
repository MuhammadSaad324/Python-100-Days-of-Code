# Make a Quiz Brain Class for Setting the Question Number and Question list for Showing Questions
class QuizBrain:
    def __init__(self,question_list):
        self.question_number = 0
        self.question_list = question_list
        self.score = 0


    def still_question(self):
        if self.question_number < len(self.question_list):
            return True
        else:
            return False

    def show_question(self):
        current_question = self.question_list[self.question_number]
        self.question_number += 1
        user_answer = input(f"Q.{self.question_number} {current_question.question} (True/False)?: ")
        self.check_answer(user_answer,current_question.correct_answer)

    def check_answer(self,user_answer,correct_answer):
        if user_answer.lower() == correct_answer.lower():
            self.score +=1
            print(f"You Got it Right.")

        else:
            print(f"Your Answer is Wrong.")
        print(f"The Right Answer Was {correct_answer}")
        print(f"Current Score is {self.score}/{self.question_number}")



