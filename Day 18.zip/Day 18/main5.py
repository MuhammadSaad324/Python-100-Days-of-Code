# Draw A Spirograph
import turtle as t
from turtle import Screen
import random

timmy = t.Turtle()
timmy.shape("turtle")
timmy.color("purple")
timmy.speed(0)
t.colormode(255)

def random_colors():
    r = random.randint(1,255)
    g = random.randint(1,255)
    b = random.randint(1,255)
    random_color = (r,g,b)
    return random_color

def draw_spirograph(gap_size):
    for _ in range(360 // gap_size):
        timmy.color(random_colors())
        timmy.circle(100)
        timmy.setheading(timmy.heading() + gap_size)

draw_spirograph(5)

#
# def draw_spirograph(gap_size):
#     for _ in range(int(360 / gap_size)):
#         timmy.color(random_colors())
#         timmy.circle(100)
#         timmy.setheading(timmy.heading() + gap_size)
#
# draw_spirograph(2)
#
#
#

# colors = ["red","black"]
# def draw_spirograph(gap_size):
#     for _ in range(int(360 / gap_size)):
#         # timmy.color(random_colors())
#         timmy.color(random.choice(colors))
#         timmy.circle(100)
#         timmy.setheading(timmy.heading() + gap_size)
#
# draw_spirograph(0.6)







screen = Screen()
screen.exitonclick()