import pandas

# First Read Weather CSV
data = pandas.read_csv("weather_data.csv")
print(data)

# Convert Data Frame into Dictionary using Pandas
data_dict = data.to_dict()
print(data_dict)

# Get Temperature Data Covert it into a List
temp_data = data["temp"].tolist()
average_temp = sum(temp_data) // len(temp_data)
print(average_temp)

temp = data["temp"]
average_temperature = round(temp.mean(),2)
print(average_temperature)

# Get Maximum Using Pandas Method
temp_numbers = data["temp"]
max_temp = temp_numbers.max()
print(max_temp)

# Extract Rows And Work With Them
max_temp = data[data.temp == temp.max()]
print(max_temp)


# Get Monday Temp from Row and Convert it into Fahrenheit
monday = data[data.day == "Monday"]
monday_temp = monday.temp[0]
monday_to_F = (monday_temp * 9/5) + 32
print(monday_to_F)

# Create Data Frame From Raw and Make it's CSV File
game_characters = {
    "Names" : ["Ghost","Soap","Captain Price","Viktor Reznov","Simon Ghost","Gaz"],
    "Age" : [24,34,42,33,30,29]
}

game_data = pandas.DataFrame(game_characters)
game_data.to_csv("game_file.csv")