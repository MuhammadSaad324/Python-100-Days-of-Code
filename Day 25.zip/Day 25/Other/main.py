import pandas

data = pandas.read_csv("weather_data.csv")

# Convert the Dataframe into dictionary
# data_dict = data.to_dict()
# print(data_dict)
#
# # Now Work with Series
# temp_list = data["temp"].tolist()
#
# # Using Traditional Approach
# def average(numbers):
#     return round(sum(numbers) / len(numbers),2)
#
# Average = average(temp_list)
# print(Average)
#
# # By Using Pandas library
# series_data = data["temp"]
# average = series_data.mean()
# print(average)
#
# # Find the max number from the List
#
# max_number = data["temp"]
# print(max_number.max())
#
# print(data[data.temp == data.temp.max()])




# Get data in Row
# Convert Monday Temperature into Fahrenheit

# monday = data[data.day == "Monday"]
# monday_temp = monday.temp[0]
# monday_temp_F = (monday_temp * 9/5) + 32
# print(monday_temp_F)


# Create Data Frame from Scratch
students_dict = {
    "Names": ["Michael","James","Emmy"],
    "Marks":[12,56,100]
}

student_data_frame = pandas.DataFrame(students_dict)
print(student_data_frame)

# Convert it into CSV File
student_data_frame.to_csv("new_file.csv")