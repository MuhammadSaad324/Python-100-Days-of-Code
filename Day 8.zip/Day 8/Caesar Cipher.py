# Let's Make Caesar Cypher
caesar_logo = r'''
   _____ ______          _____                      _____  _                 
  / ____|  ____|   /\   |  __ \                    / ____|| |                
 | |    | |__     /  \  | |__) |_ _ ___ ___  ___  | |     | |__   __ _ _ __  
 | |    |  __|   / /\ \ |  ___/ _` / __/ __|/ _ \ | |     | '_ \ / _` | '_ \ 
 | |____| |____ / ____ \| |  | (_| \__ \__ \  __/ | |____ | | | | (_| | | | |
  \_____|______/_/    \_\_|   \__,_|___/___/\___|  \_____||_| |_|\__,_|_| |_|
'''
print(caesar_logo)

alphabet = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']

def caesar():
    direction = input("Type 'encode' to encrypt, type 'decode' to decrypt:\n").lower()
    text = input("Type your message:\n").lower()
    shift = int(input("Type the shift number:\n"))
    if direction=='encode':
        def encrypt(original_text,shift_number):
            encryted_text=""
            for x in original_text:
                if x !=" ":
                    alphabet_index=alphabet.index(x) + shift_number
                    alphabet_index %=len(alphabet)
                    encryted_text+=alphabet[alphabet_index]
            print(f"Your Encrypted text is : {encryted_text}")
        encrypt(original_text=text,shift_number=shift)
    else:
        def decrypt(original_text,shift_number):
            decrypted_text=""
            for x in original_text:
                if x!=" ":
                    alphabet_index=alphabet.index(x) - shift_number
                    alphabet_index%=len(alphabet)
                    decrypted_text+=alphabet[alphabet_index]
            print(decrypted_text)
        decrypt(shift_number=shift,original_text=text)
caesar()

while True:
    start_again=input("Press Y if you want to Start Again Or N to Not? ").lower()
    if start_again=='y':
        caesar()
    else:
        print("Good Bye")
    break
