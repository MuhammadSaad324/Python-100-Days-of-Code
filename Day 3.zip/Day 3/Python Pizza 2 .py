print("Welcome to Python Pizza Deliveries!")
size = input("What size pizza do you want? S, M or L: ")
pepperoni = input("Do you want pepperoni on your pizza? Y or N: ")
extra_cheese = input("Do you want extra cheese? Y or N: ")
Small_Pizza=15
Medium_Pizza=20
Large_Pizza=25
Final_Bill=0
if size=="S".lower():
    Final_Bill+=Small_Pizza
elif size=="M".lower():
    Final_Bill+Medium_Pizza
else:
    Final_Bill+=Large_Pizza
if size=="S".lower():
    if pepperoni=="Y".lower():
        Final_Bill+=2
else:
    Final_Bill+=3
if extra_cheese=="Y":
    Final_Bill+=1
print(f"Your Final Bill is ${Final_Bill}")
