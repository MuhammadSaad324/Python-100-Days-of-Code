import heroes

heroes_names = heroes.genarr(500)
