# Welcome To The Summary of 100 Days Of Code In Python Course
# In Day 1 We Learn About String, String Manuplation, Concatenation , Debugging ,Input() , Len(),Commenting
# Variables , Variables Naming And At Last We Completed A Project Using All These

print("Saad")
# Escape Characters
print("My Name is Saad\nAnd I am a Billionaie\nI Have Billions Of Dollars In My Accounts.")

# String Concatenation
print("Hello"+" "+"Saad")

#Band Name Generator
print("Welcome to Band Name Generator")
City_Name=input("What's the Name Of Your City?\n ")
print(City_Name)
Pet_Name=input("What's Your Pet's Name?\n ")
print(Pet_Name)
print("Your Band Name Could Be :"+City_Name+" "+Pet_Name)