with open (r"C:\Users\DELL\Desktop\new_file.txt") as new_file:
    content = new_file.read()
    print(content)