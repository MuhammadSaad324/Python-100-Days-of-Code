capital_cities={
    "France":"Paris",
    "Russia":"Moscow",
    "China":"Beijing"
}

# Now Print Lille from the Nested List
travel_log = {
    "France": ["Paris", "Lille", "Dijon"],
    "Germany": ["Stuttgart", "Berlin"],
}

print(travel_log["France"][1])

# Now Print "D" from the list
nested_list = ["A", "B", ["C", "D"]]
print(nested_list[2][1])

# Print Stuttgart from the Dictionary
new_travel_log={
    "France":{
        "cities_visited":["Lille","Paris","Nantes"],
        "total_visits":12
    },
    "Germany":{
        "cities_visited":["Berlin","Hamburg","Stuttgart"],
        "total_visits":5
    }
}
print(new_travel_log["Germany"]["cities_visited"][2])