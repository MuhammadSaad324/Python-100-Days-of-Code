# Now we are going to Use Event Listeners for Controlling the movement of Our Turtle
from turtle import Turtle,Screen

shelby = Turtle()
shelby.shape("turtle")


# function for moving my turtle back and forth
def forward():
    shelby.forward(100)

def backward():
    shelby.backward(50)
def left():
    shelby.left(20)

def right():
    shelby.right(20)

def clear():
    shelby.home()
    shelby.clear()

screen = Screen()
screen.onkey(forward,"w")
screen.onkey(backward,"s")
screen.onkey(left,"a")
screen.onkey(right,"d")
screen.onkey(clear,"c")
screen.listen()



screen.exitonclick()