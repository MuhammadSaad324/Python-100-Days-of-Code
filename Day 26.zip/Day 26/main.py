# Today I learnt About List Comprehension , Conditional List Comprehension

# Problem 1 Do Square of Each Number Using List Comprehension

# numbers = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55]
# squared_numbers = [num * num for num in numbers]
# print(squared_numbers)

# Problem 2
# list_of_strings = ['9', '0', '32', '8', '2', '8', '64', '29', '42', '99']
# numbers = [int(num) for num in list_of_strings]
# result = [even_num for even_num in numbers if even_num % 2 ==0]
# print(result)

# Problem 3 Data Overlap
# list_1 = [3,6,5,8,33,12,7,4,72,2,42,13]
# list_2 = [3,6,13,5,7,89,12,3,33,34,1,344,42]
#
# result = [num for num in list_1 if num in list_2]
# print(result)

# Problem 4
square = [n*n for n in range(1,11)]

# Problem 5
nums = [even for even in range(1,21) if even % 2 ==0]
print(nums)

# Problem 6
words = ["apple", "banana", "cherry"]
words_length = [len(letter) for letter in words]
print(words_length)

# Problem 7
words_2 = ["apple", "banana", "cherry"]
first_letter = [first[0] for first in words_2]
print(first_letter)

# Problem 8
new_words = ['hello', 'world', 'python']
all_caps = [word.upper() for word in new_words]
print(all_caps)

# Problem 9
numbers = [digits for digits in range(1,51) if digits % 3 == 0 if digits % 5 != 0]
print(numbers)

# Problem 10
matrix = [[1, 2], [3, 4], [5, 6]]
new_list = []
[new_list.extend(x) if type(x) is list else new_list.append(x) for x in matrix]
print(new_list)

# Problem 11
name =  "ab3cd4e5"
name_list = [int(char) for item in name for char in str(item) if char.isdigit()]
print(name_list)

# Problem 12
nums = [1, 2, 3, 4, 5, 6]
new_nums = [all_nums for all_nums in nums if all_nums % 2 == 0 if all_nums % 2 != 0]

# Problem 13
new_numbers = [(x,x*x) for x in range(1,11)]
print(new_numbers)
