# Draw a All Shapes Polygon and Dashed Line

from turtle import Turtle,Screen
import  math

my_turtle = Turtle()

my_turtle.shape("turtle")
my_turtle.color('darkred')

# for _ in range(15):
#     my_turtle.forward(10)
#     my_turtle.penup()
#     my_turtle.forward(10)
#     my_turtle.pendown()

def draw_polygon(turtle_obj, sides, radius):
    angle = 360 / sides
    side_length = 2 * radius * math.sin(math.pi / sides)

    turtle_obj.penup()
    turtle_obj.goto(0, 0)  # Go to the center
    turtle_obj.setheading(90)  # Point straight up
    turtle_obj.forward(radius)
    turtle_obj.right(180 - (180 * (sides - 2) / (2 * sides)))  # Rotate to align top point
    turtle_obj.pendown()

    for _ in range(sides):
        turtle_obj.forward(side_length)
        turtle_obj.right(angle)

# Set up turtle
my_turtle.speed(50)
my_turtle.pencolor("red")

# Draw shapes from triangle to decagon
radius = 50
for sides in range(3, 11):  # From triangle (3 sides) to decagon (10 sides)
    draw_polygon(my_turtle, sides, radius)
    radius += 10  # Increase radius for each new polygon


# Wait for user to click to exit
screen = Screen()
screen.exitonclick()



