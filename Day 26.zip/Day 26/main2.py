import random
import pandas

# List Comprehension
numbers_list = [1,2,3,4,5,6]
add_three = [num+3 for num in numbers_list]
print(add_three)

# Dictionary Comprehension
names_list = ["Michael","Ian Bell","Reznov","Joshua","Jordan"]
students_list = {names : random.randint(1,100)  for names in names_list}
passed_students ={passed:marks for (passed,marks) in students_list.items() if marks >= 60}
print(passed_students)


# Dictionary Comprehension
# Problem 1

numbers = [1,2,3,4,5]
numbers_squares = {num : num**2 for num in numbers}
print(numbers_squares)

# Problem 2
words = ['apple', 'banana', 'cherry']
words_length  = {x : len(x) for x in words}
print(words_length)

# Problem 3
new_numbers_list = [1,2,3,4,5,6,7,8,9,10]
new_numbers_list_even = {n : n**2 for n in new_numbers_list if n % 2 == 0}
print(new_numbers_list_even)

# Problem 4
original_letters = ['a', 'b', 'c']
original_letters_dict = {letter : letter.upper() for letter in original_letters}
print(original_letters_dict)

# Problem 5
sentence = "What is the Airspeed Velocity of an Unladen Swallow?"
sentence_list = sentence.split()
result = {word : len(word) for word in sentence_list}
print(result)

# Problem 6
weather_c = {"Monday": 12, "Tuesday": 14, "Wednesday": 15, "Thursday": 14, "Friday": 21, "Saturday": 22, "Sunday": 24}

weather_f = {day : (temp * 9/5) + 32 for (day,temp) in weather_c.items()}

print(weather_f)

# Pandas iterrows method
students_data = {
    "Names" : ["Michael","Evans","Alex Hales","Morgan"],
    "Marks" : [67,50,72,21]
}

students_data_frame = pandas.DataFrame(students_data)
print(students_data_frame)

for (index,rows) in students_data_frame.iterrows():
    print(rows.Names)
    print(rows.Marks)
