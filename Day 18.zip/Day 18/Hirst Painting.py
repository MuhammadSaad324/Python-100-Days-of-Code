###This code will not work in repl.it as there is no access to the colorgram package here.###
##We talk about this in the video tutorials##
import turtle as t
from turtle import Screen
import random
colors_List = [(245, 243, 238), (246, 242, 244), (202, 164, 110), (240, 245, 241), (236, 239, 243), (149, 75, 50), (222, 201, 136), (53, 93, 123), (170, 154, 41), (138, 31, 20), (134, 163, 184), (197, 92, 73), (47, 121, 86), (73, 43, 35), (145, 178, 149), (14, 98, 70), (232, 176, 165), (160, 142, 158), (54, 45, 50), (101, 75, 77), (183, 205, 171), (36, 60, 74), (19, 86, 89), (82, 148, 129), (147, 17, 19), (27, 68, 102), (12, 70, 64), (107, 127, 153), (176, 192, 208), (168, 99, 102)]

timmy = t.Turtle()
timmy.penup()
timmy.shape("turtle")
timmy.setx(-250)
t.colormode(255)
timmy.speed("fastest")
timmy.hideturtle()

def draw_grid_circles(rows, cols, gap=30):
    y_start = rows * gap // 2  # Start from top
    x_start = -cols * gap // 2  # Center horizontally
    timmy.penup()
    timmy.goto(x_start, y_start)
    x = x_start
    y = y_start

    for i in range(rows * cols):
        timmy.color(random.choice(colors_List))
        timmy.begin_fill()
        timmy.circle(10)
        timmy.end_fill()
        timmy.penup()
        timmy.forward(gap)

        # Move to next line after every `cols` circles
        if (i + 1) % cols == 0:
            y -= gap  # Go down a row
            timmy.goto(x_start, y)

draw_grid_circles(rows=10, cols=10)

screen = Screen()
screen.exitonclick()
