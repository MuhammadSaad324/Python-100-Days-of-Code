print("Welcome to Python Pizza Deliveries!")
size = input("What size pizza do you want? S, M or L: ")
pepperoni = input("Do you want pepperoni on your pizza? Y or N: ")
extra_cheese = input("Do you want extra cheese? Y or N: ")
Final_Bill=0
# Pizza Size Code Completed
if size=="S".lower():
    Final_Bill+=15
elif size=="M".lower():
    Final_Bill+=20
else:
    Final_Bill+=25
# Pepperoni Solved
if size=="S".lower():
    if pepperoni=="Y".lower():
        Final_Bill+=2
else:
    Final_Bill+=3
# Cheese Solution
if extra_cheese=="Y".lower():
    Final_Bill
print(f"Your Final Bill is ${Final_Bill}")
