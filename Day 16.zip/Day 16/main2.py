# So we are going to practise Class Attributes and Object Methods from Prettytable
from prettytable import PrettyTable


table = PrettyTable()
table.add_column("Pokemon Name",["Mothim","Pikachu","Azumarill","Goldeen","Sharpedo"])
table.add_column("Type", ["Flying","Electric","Water","Water","Dark"])
table.align="l"


print(table)


