# def is_leap_year(year):
#     if year % 4 ==0:
#         if year % 100 == 0:
#             if year % 400 ==0:
#                 print("Leap Year")
#             else:
#                 print("Not Leap Year")
#         else:
#             print("Leap Year")
#     else:
#         print("Not Leap Year")
# is_leap_year(2000)


def is_leap_year(year):
    if year % 4 ==0:
        if year % 100 ==0:
            if year % 400 ==0:
                return True
            return False
        return True
    return False
print(is_leap_year(2100))


def eligible(age):
    if type(age) != int:
        return
    if age >=18:
        return "Eligible"
    else:
        return "Not Eligible"
print(eligible("Saad"))

