#TODO: Create a letter using starting_letter.txt 
#for each name in invited_names.txt
#Replace the [name] placeholder with the actual name.
#Save the letters in the folder "ReadyToSend".

# Step 1 Extract names from names file
all_names = []
with open(r"D:\100 Days Of Code\Day 24\Mail Merge Project Start\Input\Names\invited_names.txt") as names_file:
    for names in names_file:
        striped_names = names.strip()
        all_names.append(striped_names)
# Step 2 Read letter and replace name placeholder with actual name
with open(r"D:\100 Days Of Code\Day 24\Mail Merge Project Start\Input\Letters\starting_letter.txt") as letter_file:
    letter_template = letter_file.read()
    for name in all_names:
        personalised_letter = letter_template.replace("[name]", name)
        with open(fr"D:\100 Days Of Code\Day 24\Mail Merge Project Start\Output\ReadyToSend\letter_for_{name}.txt",mode="w") as output_file:
            output_file.write(personalised_letter)

