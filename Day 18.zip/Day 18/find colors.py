import turtle as t
from turtle import Screen
import random

colors_list = [(181, 2, 0), (248, 133, 0), (254, 138, 6), (240, 75, 2), (161, 8, 13), (83, 7, 17), (95, 2, 1), (253, 71, 8), (11, 17, 29), (113, 58, 68), (68, 75, 87), (59, 61, 74), (249, 11, 8), (2, 7, 5), (209, 62, 68), (18, 81, 96), (121, 151, 162), (191, 129, 139), (255, 191, 19), (75, 101, 97), (247, 10, 12), (34, 78, 76), (95, 139, 149), (130, 140, 137), (255, 208, 151), (121, 133, 126), (74, 65, 50), (126, 125, 141)]



timmy = t.Turtle()
timmy.penup()
timmy.shape("turtle")
timmy.setx(-250)
t.colormode(255)
timmy.speed("fastest")

def draw_grid_circles(rows, cols, gap=30):
    y_start = rows * gap // 2  # Start from top
    x_start = -cols * gap // 2  # Center horizontally
    timmy.penup()
    timmy.goto(x_start, y_start)
    x = x_start
    y = y_start

    for i in range(rows * cols):
        timmy.color(random.choice(colors_list))
        timmy.begin_fill()
        timmy.circle(10)
        timmy.end_fill()
        timmy.penup()
        timmy.forward(gap)

        # Move to next line after every `cols` circles
        if (i + 1) % cols == 0:
            y -= gap  # Go down a row
            timmy.goto(x_start, y)

draw_grid_circles(rows=10, cols=10)

screen = Screen()
screen.exitonclick()
