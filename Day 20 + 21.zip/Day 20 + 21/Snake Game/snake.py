from turtle import Turtle


MOVE_DISTANCE = 20
UP = 90
DOWN = 270
RIGHT = 0
LEFT = 180
class Snake:
    def __init__(self):
        self.all_turtles = []
        self.create_snake()
        self.head = self.all_turtles[0]

    def create_snake(self):
        starting_positions = [(0, 0), (-20, 0), (-40, 0)]
        for position in starting_positions:
            self.add_segment(position)

    def add_segment(self, position=(0, 0)):
            timmy = Turtle(shape="square")
            timmy.color("white")
            timmy.penup()
            timmy.goto(position)
            self.all_turtles.append(timmy)

    def reset(self):
        for turtle in self.all_turtles:
            turtle.goto(1000,1000)
        self.all_turtles.clear()
        self.create_snake()
        self.head = self.all_turtles[0]

    def extend(self):
        self.add_segment(self.all_turtles[-1].position())

    def move(self):
        for squares in range(len(self.all_turtles) - 1, 0, -1):
            new_x = self.all_turtles[squares - 1].xcor()
            new_y = self.all_turtles[squares - 1].ycor()
            self.all_turtles[squares].goto(new_x, new_y)
        self.head.forward(MOVE_DISTANCE)

    def up (self):
        if self.head.heading != DOWN:
            self.all_turtles[0].setheading(UP)
    def down(self):
        if self.head.heading != UP:
            self.all_turtles[0].setheading(DOWN)
    def right(self):
        if self.head.heading != LEFT:
            self.all_turtles[0].setheading(RIGHT)
    def left(self):
        if self.head.heading != RIGHT:
            self.all_turtles[0].setheading(LEFT)
