# Treasure Island Game
print(
    r'''
*******************************************************************************
          |                   |                  |                     |
 _________|________________.=""_;=.______________|_____________________|_______
|                   |  ,-"_,=""     `"=.|                  |
|___________________|__"=._o`"-._        `"=.______________|___________________
          |                `"=._o`"=._      _`"=._                     |
 _________|_____________________:=._o "=._."_.-="'"=.__________________|_______
|                   |    __.--" , ; `"=._o." ,-"""-._ ".   |
|___________________|_._"  ,. .` ` `` ,  `"-._"-._   ". '__|___________________
          |           |o`"=._` , "` `; .". ,  "-._"-._; ;              |
 _________|___________| ;`-.o`"=._; ." ` '`."\ ` . "-._ /_______________|_______
|                   | |o ;    `"-.o`"=._``  '` " ,__.--o;   |
|___________________|_| ;     (#) `-.o `"=.`_.--"_o.-; ;___|___________________
____/______/______/___|o;._    "      `".o|o_.--"    ;o;____/______/______/____
/______/______/______/_"=._o--._        ; | ;        ; ;/______/______/______/_
____/______/______/______/__"=._o--._   ;o|o;     _._;o;____/______/______/____
/______/______/______/______/____"=._o._; | ;_.--"o.--"_/______/______/______/_
____/______/______/______/______/_____"=.o|o_.--""___/______/______/______/____
/______/______/______/______/______/______/______/______/______/______/_____ /
*******************************************************************************
'''
)
print("Welcome to Treasure Island.")
print("Your mission is to find the treasure.")

Direction = input("Left Or Right? ").lower()

if Direction == "left":
    print("You reached a river.")
    Choice = input("Swim or Wait? ").lower()

    if Choice == "wait":
        Build = input("Take a Boat or Build Raft? ").lower()
        if Build == "build raft":
            print("You cross safely.")
        else:
            print("Pirates trap you. Game Over.")
            exit()

        Fight = input("Fight Monsters? Fight or Run? ").lower()
        if Fight == "fight":
            print("You win! Proceeding...")
        else:
            print("Monster eats you. Game Over.")
            exit()

        print("Here's a new thing coming in the game...")
        Magic_Mirror = input("Magic Mirror shows two paths: Gold or Light? ").lower()
        if Magic_Mirror == "light":
            print("You chose the right path. Proceed to doors...")
        else:
            print("You were trapped by illusion. Game Over.")
            exit()

        Doors = input("Doors are here! Pick one: Red, Blue or Yellow? ").lower()
        if Doors == "red":
            print("Burned by fire. Game Over.")
        elif Doors == "blue":
            print("Eaten by beasts. Game Over.")
        elif Doors == "yellow":
            Code = input("Enter the code (What do you say before eating?): ").lower()
            if Code == "bismillah":
                print("You found the treasure! You Win!")
            else:
                print("Wrong code! Door explodes. Game Over.")
        else:
            print("Invalid door. Game Over.")

    else:
        print("Attacked by trout. Game Over.")

elif Direction == "right":
    Cave_Jungle = input("You see two paths: Cave or Jungle? ").lower()
    if Cave_Jungle == "cave":
        print("Bats eat you. Game Over.")
    elif Cave_Jungle == "jungle":
        print("You found a map to the treasure. Proceed...")
        # You can continue from here if you want
    else:
        print("You got lost. Game Over.")

else:
    print("You got lost. Game Over.")
