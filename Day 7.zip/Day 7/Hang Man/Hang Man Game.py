import random
from hangman_words import Words_List
from hangman_art import logo, stages
stages = [r'''
  +---+
  |   |
  O   |
 /|\  |
 / \  |
      |
=========
''', r'''
  +---+
  |   |
  O   |
 /|\  |
 /    |
      |
=========
''', r'''
  +---+
  |   |
  O   |
 /|\  |
      |
      |
=========
''', '''
  +---+
  |   |
  O   |
 /|   |
      |
      |
=========''', '''
  +---+
  |   |
  O   |
  |   |
      |
      |
=========
''', '''
  +---+
  |   |
  O   |
      |
      |
      |
=========
''', '''
  +---+
  |   |
      |
      |
      |
      |
=========
''']
print(logo)

# Will Print Words from Words-List Randomly
chosen_words=random.choice(Words_List)
print(chosen_words)
lives=5
# Add Blanks According to the Length of the Word
placeholder=""
for letter in range(len(chosen_words)):
    placeholder+="-"
print(placeholder)

# for displaying guessed Letter in the display
Guessed_Letters=[]
User_Won=False

while not User_Won: 
    guess=input("Guess a Letter From The Word? ")
    if guess in Guessed_Letters:
        print(f"You Already Guesses This Letter.")
    display=""
    for letters in chosen_words:
        if letters==guess:
            display+=letters
            Guessed_Letters.append(guess)
        elif letters in Guessed_Letters:
            display+=letters
        else:
            display+="-"
    print(display)

    if guess not in display:
        lives-=1
        print(f"Remaining Lives {lives}")
        if lives==0:
            User_Won=False
            print("You Lose The Game.")
            print(f"**********************The Words was {chosen_words}********************")
    
    if "-" not in display:
        User_Won=False
        print("You Win the Game.")
print(stages[lives])
